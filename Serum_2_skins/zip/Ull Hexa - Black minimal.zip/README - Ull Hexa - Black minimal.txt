Ull Hexa - Black minimal
A custom interface skin for Xfer Serum 2
Ull Hexa | https://www.ullhexa.com

This download changes Serum 2's appearance. It does not include Serum 2,
sound presets or an installer. A separately licensed copy of Serum 2 is
required. These files are for Serum 2, not Serum 1.

WHAT TO INSTALL

After extracting the ZIP, you will find:

  Ull Hexa - Black minimal/
      1x/
      2x/
      Fonts/
  README - Ull Hexa - Black minimal.txt
  LICENSE - Ull Hexa Skins.txt

Install the entire "Ull Hexa - Black minimal" folder, with all three
subfolders intact. Leave these two text documents outside the skin folder;
they are for your reference and do not need to be copied into Serum.

BEFORE INSTALLING

Back up your Serum presets and settings. Do not replace the factory Default
skin, plugin or program files. Install only the skin folder described below.

INSTALLATION - macOS AND WINDOWS

1. Extract the ZIP completely. On macOS, double-click it. On Windows,
   right-click it and choose "Extract All...".

2. Open Serum 2 in your DAW. In Serum 2's MENU, choose
   "Open Serum 2 Presets Folder". Some versions use similar wording such
   as "Show Serum Presets folder". This opens the content folder actually
   used by your copy of Serum, including if it was moved to another drive.

3. Inside that folder, open "Skins". Copy the complete
   "Ull Hexa - Black minimal" folder into it. The result must be:

   Serum 2 Presets/
       Skins/
           Ull Hexa - Black minimal/
               1x/
               2x/
               Fonts/

   Do not put it inside the separate "Presets" subfolder or inside "Default".
   Do not copy the PNGs individually, split up 1x and 2x, or install the
   bundled fonts into your operating system. Serum reads them from the skin.
   If your unzip tool adds an outer folder, copy only the inner skin folder
   that directly contains 1x, 2x and Fonts.

4. Close and reopen Serum 2's interface. Click the logo in the upper-left
   corner, open the "Skins" submenu and select "Ull Hexa - Black minimal".
   If the name does not appear, restart your DAW and check the folder
   structure above. With an Ull Hexa skin active, the logo is the ULL logo.

COMMON FOLDER LOCATIONS

Use the menu method above first; custom installations may use another path.

macOS:
  /Library/Audio/Presets/Xfer Records/Serum 2 Presets/Skins/

  This is the computer's main Library folder. In Finder, choose
  Go > Go to Folder and paste the path above to open it.

Windows:
  C:\Users\<your username>\Documents\Xfer\Serum 2 Presets\Skins\

  If Windows redirects Documents to OneDrive, the path may instead be:
  C:\Users\<your username>\OneDrive\Documents\Xfer\Serum 2 Presets\Skins\

UPDATING OR REMOVING A SKIN

For an update, close your DAW, back up the existing folder with this skin's
name, and replace that folder with the complete new version. Keep the
factory Default folder and other skins unchanged.

To remove it, select another skin first, close your DAW, and remove only
this skin's folder from Skins.

If the skin looks incomplete, confirm that both resolution folders and
Fonts were copied in full. If Serum cannot find its content folder, follow
Xfer Records' support instructions rather than replacing factory files.

USE AND COPYRIGHT

Read "LICENSE - Ull Hexa Skins.txt" before using or sharing this skin.
Use in personal and commercial music production is free. You may share the
complete, unchanged package for free, keeping the Ull Hexa branding, licence
and notices intact and identifying https://www.ullhexa.com as the source.
Do not sell it, distribute rebranded or modified versions, reuse its assets
in other products, or claim ownership of Ull Hexa's original material.

Except where applicable law requires otherwise, no support, replies, fixes,
updates, continued availability or future compatibility are promised. The skin
is supplied as is. Warranty and installation-related liability limitations,
and the mandatory-law exceptions to those limitations, are in the licence.

This is an independent Ull Hexa product. It is not affiliated with,
sponsored by or endorsed by Xfer Records. Serum and Xfer Records names
identify the compatible third-party product and its owner.

Downloads and contact: https://www.ullhexa.com
Official Serum 2 manual: https://xferrecords.com/manual/serum-2
Official Serum support: https://support.xferrecords.com

Documentation version: 1.2 | 13 October 2026
